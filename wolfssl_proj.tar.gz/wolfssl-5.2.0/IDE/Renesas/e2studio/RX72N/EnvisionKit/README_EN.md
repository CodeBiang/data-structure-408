wolfSSL sample application project for Renesas RX72N EnvisionKit evaluation board
======

<br>

A sample program for evaluating wolfSSL targeting the Renesas RX72N EnvisionKit evaluation board is provided. For details on the program, refer to the following documents included in the package. 

+ InstructionManualForExample_RX72N_EnvisonKit_JP.pdf (Japanese)
+ InstructionManualForExample_RX72N_EnvisonKit_EN.pdf(English）