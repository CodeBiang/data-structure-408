# wolfSSL Crypt Test Example

The Example contains of wolfSSL test program.

When you want to run the benchmark program
1. `idf.py menuconfig` to configure the program,first
2. `idf.py build` to compile and `idf.py -p <PORT> flash` to load the firmware
3. `idf.py monitor` to see the message

See the README.md file in the upper level 'examples' directory for more information about examples.
