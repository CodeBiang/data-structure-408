#ifndef __SSTK_PORTABLE_CONFIG_
#define __SSTK_PORTABLE_CONFIG_

#define SSTK_THREADS 1

#define SSTK_ARCH SSTK_ARCH_TI_OS

#include "sstk_ti_pthread_spinlock.h"

#endif // __SSTK_PORTABLE_CONFIG_
