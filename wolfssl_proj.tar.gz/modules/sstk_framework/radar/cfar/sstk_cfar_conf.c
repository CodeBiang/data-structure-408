#include "sstk_cfar.h"


sstk_int_t sstk_cfar_conf_handler(sstk_conf_t* conf, sstk_uint_t type, void* data) {
    // sstk_chain_t* chain = conf->chain;
    
    return SSTK_ERR;
}
