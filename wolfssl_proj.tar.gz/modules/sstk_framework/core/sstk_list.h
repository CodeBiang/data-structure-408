/**
 * @file    
 * @date    2021/5/12
 * @author  赵陈淏
 * @brief   通用链表
 *          已废弃 使用queue双向链表实现链表 @see sstk_queue.h
 */
#ifndef __SSTK_LIST_H_
#define __SSTK_LIST_H_

#include <sstk_core.h>

#endif
