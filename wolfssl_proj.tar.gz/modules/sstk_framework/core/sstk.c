#include "sstk.h"

#define SSTK_FRAMEWORK_VERSION "1.0.1"


const char* sstk_framework_version() {
    return SSTK_FRAMEWORK_VERSION;
}
