#ifndef __SSTK_MACRO_H_
#define __SSTK_MACRO_H_

#define __generic(__type)

#endif 
