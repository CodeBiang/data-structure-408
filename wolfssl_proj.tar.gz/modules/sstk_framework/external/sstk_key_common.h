#ifndef __SSTK_KEY_COMMON_H_
#define __SSTK_KEY_COMMON_H_

#include <sstk_core.h>

extern sstk_key_base_t sstk_int_key_base;
extern sstk_key_base_t sstk_str_key_base;

#endif
