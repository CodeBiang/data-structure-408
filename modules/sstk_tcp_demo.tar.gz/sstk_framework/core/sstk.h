/**
 * @file    
 * @date    2021/5/12
 * @author  赵陈淏
 * @brief   
 */
#ifndef __SSTK_H_
#define __SSTK_H_

const char* sstk_framework_version();

#endif
