#ifndef __CERTS_H__
#define __CERTS_H__

#define CA_CERT_BUF                                                    \
    "-----BEGIN CERTIFICATE-----"                                      \
    "MIIDkTCCAnmgAwIBAgIBAzANBgkqhkiG9w0BAQsFADB+MQswCQYDVQQGEwJDTjEO" \
    "MAwGA1UECAwFSGViZWkxFTATBgNVBAcMDFNoaWppYXpodWFuZzENMAsGA1UECgwE" \
    "V0hTVDENMAsGA1UECwwERURHRTELMAkGA1UEAwwCQ0ExHTAbBgkqhkiG9w0BCQEW" \
    "DjIwMDU1QHdoc3QuY29tMB4XDTIyMDMxODAxNDgzNloXDTMyMDMxNTAxNDgzNlow" \
    "fjELMAkGA1UEBhMCQ04xDjAMBgNVBAgMBUhlYmVpMRUwEwYDVQQHDAxTaGlqaWF6" \
    "aHVhbmcxDTALBgNVBAoMBFdIU1QxDTALBgNVBAsMBEVER0UxCzAJBgNVBAMMAkNB" \
    "MR0wGwYJKoZIhvcNAQkBFg4yMDA1NUB3aHN0LmNvbTCCASIwDQYJKoZIhvcNAQEB" \
    "BQADggEPADCCAQoCggEBANBD9JpGROROl6xbxfOBCqDRFnrJwC9v5e2OUl4+6yoT" \
    "OGoEUAlBVAgEb0QNx4GX56/1TUOexe0MOhGP5v6tJWoP4PBZcYyUxtfAH5HOZ31e" \
    "nPmVHTrvwAx6lQ6axuS6PFlC4V6Vl4uLx/calG0fda4xee0QyCJ2NwboojzG5zzx" \
    "3PJWnBmWFk1EjvgUt/oZc0I5E/1X6eK+w3Kiax3LGtvJT/dmSeeqbtrrn2Uw8gSF" \
    "UYvgNJDXGRFvpavm+KZkbxNsYtp26LxvoYnA938GNpb9Xf6p4Zx8BhKjJaBkgb/t" \
    "mi2aKENa6gxYHzg4CaZqklnMvfMZE+WH1nwHCOTpCMMCAwEAAaMaMBgwCQYDVR0T" \
    "BAIwADALBgNVHQ8EBAMCBeAwDQYJKoZIhvcNAQELBQADggEBAD/BKyzOEwXdQHDL" \
    "kBxgFo2poztTc874mEhRiCGNOB3ArCMcdv/UA+dDsbsDnmGq9h9wbuNk5DARYifL" \
    "Qw1rxWB6zIfvNah9kYfePRHmigqXWXQ2r9MyFfW3etKN91F3Gitka3UUaU7dlakN" \
    "+YkIlB3bXw22o+6UAOdBsTaUEJnlEpQaIk969SHCWskyCBcZlVVqO0hski+RAMuH" \
    "aiK8Uawn2x7Z3v23NavcUyhkKOjfEqDkk/0/KEHcwGDbcqnQsHJsyiVsQofQkIZd" \
    "86TluaT9k5p0aL7/VtQNwR+G+8eS3bq1nGQJD6QOOlQkqf/UoFxefo+dzxrt74pt" \
    "r7W1N2E="                                                         \
    "-----END CERTIFICATE-----"

#define SVR_CERT_BUF                                                   \
    "-----BEGIN CERTIFICATE-----"                                      \
    "MIIDljCCAn6gAwIBAgIBAzANBgkqhkiG9w0BAQsFADB+MQswCQYDVQQGEwJDTjEO" \
    "MAwGA1UECAwFSGViZWkxFTATBgNVBAcMDFNoaWppYXpodWFuZzENMAsGA1UECgwE" \
    "V0hTVDENMAsGA1UECwwERURHRTELMAkGA1UEAwwCQ0ExHTAbBgkqhkiG9w0BCQEW" \
    "DjIwMDU1QHdoc3QuY29tMB4XDTIyMDMxODAxNDgzNloXDTIyMDQxNzAxNDgzNlow" \
    "gYIxCzAJBgNVBAYTAkNOMQ4wDAYDVQQIDAVIZWJlaTEVMBMGA1UEBwwMU2hpamlh" \
    "emh1YW5nMQ0wCwYDVQQKDARXSFNUMQ0wCwYDVQQLDARFREdFMQ8wDQYDVQQDDAZT" \
    "RVJWRVIxHTAbBgkqhkiG9w0BCQEWDjIwMDU1QHdoc3QuY29tMIIBIjANBgkqhkiG" \
    "9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvod132hw72XaIeHapA9xsHzFq9c/D0GnaypQ" \
    "VVL4aQOiQlNoqrpJOHBdZTiQHVNtq+WHqz2cMoefKA4aJb3lZRGC+adoekUpFeRJ" \
    "m2wq7TXsFcub88U5jYWQz6lM35pB8UV9615QNw+gC7DboT902oc1kVI3z6ncYQXo" \
    "GVIH5UaASJON08t22XKPq5BDjtRc2VkYTFJL32jaSqwOgb85q7B2S+tTZumaw1Xw" \
    "WeoCVMK3g0oRTbOcVgcYjTc0Ig/vsw/+On6vLicdEvSNOTPLerwCtDIuZRN+bGge" \
    "rGC3YhRCnb7x1MWNZXUxCQHFf6+MDTZHxsHdbroPoEmRWo/XRwIDAQABoxowGDAJ" \
    "BgNVHRMEAjAAMAsGA1UdDwQEAwIF4DANBgkqhkiG9w0BAQsFAAOCAQEAgx/PMexs" \
    "a3dGYLREya3v1P75wYlDpH/G31h2a9WHBMt37u9kdYQCLEsDp7WNKZbYX8Y5FJxa" \
    "GBAoM7K+ltJYXCKKe/tULn4x0ol8EU0VxVZF9BIZ3H0FEP7Wqt9jIrwQ1HlWzlZQ" \
    "Ywp2JNcowudXmE4BdcOiPF/Nosfap0/32o9KMhATtmC12zU5amyRIfkwn1PJWKnP" \
    "oPDejM8cKSDdbwJdJVP03fSMhd06J7qjcX2P39zekymBBEVI2OKxobzmMgP9o+Z7" \
    "U1obSRHcXAkcyisOHnuv9kk9arWLwth3RrV5D9l3HZ89Q9debuJnXqVlEk3YdcL9" \
    "5VUnI27FCq9jiw=="                                                 \
    "-----END CERTIFICATE-----"

#define SVR_KEY_BUF                                                    \
    "-----BEGIN ENCRYPTED PRIVATE KEY-----"                            \
    "MIIFHDBOBgkqhkiG9w0BBQ0wQTApBgkqhkiG9w0BBQwwHAQIWrKAEBFUsiICAggA" \
    "MAwGCCqGSIb3DQIJBQAwFAYIKoZIhvcNAwcECDfqXwBzOfThBIIEyO1smLg04hmD" \
    "VhonKM7c2tnuIW6miLmT/o3zYxfYRWdJ1WbYuGSIaTK/zSCtyhvK5ygzEKFdSPiL" \
    "LeGmyd4VIz8v1YxtXYU8zt58H/zDn3R0SAxv4uJMOu2UVkUZYfZSIVpZ5ZLcj+X8" \
    "sTHR1sHtheBSeDAyJnHEzN+Vq7H24RjMC8F0Wm+/WJXQKL4ajnEusXFIpPC+7Apk" \
    "ngrufpWtST3OBA28pT6y/xF04R4BJOwC3YOd849zUbo02VHCFLq0wCr5wh85O6xf" \
    "8raguadBrbRaJAwklVTHHnLLnYFT3/bZ7o4Tcz8SfrCLVzw5He4qNHX9HnS85K7m" \
    "5B5y2HwPQJRIv2XgN9ScUuQ8eVCPu4BZEH/VFbTh+Jj8r+uKdLeXZ6fuBnPTT8YR" \
    "L4le70keq10kFb1mKCdqMtStEMwa34zxWr5PRSdhU/hs6OCG/Z36a3Xy7Ti6ZAv2" \
    "dGDpdqOkevrOGM2U+jFFG5JpuQTIKNCRyZdZ2jl1TUtK2O2qjm1J5eaXHgPJl6D7" \
    "9ekBsvKCXoOWjYUNHy047C1SX8oJNabnojK1bserhdTPEgCUkw75+8QoX2/YEtKz" \
    "HKs9gjf6dd2J4Dq3tCrkd1/+J5jpk9++SHu6vUnnzYvsYn3ly4+qcFYrl5OAmrAc" \
    "3c20nA+AVrQQabxks782qOFH6KunKv55rrKGm7wr/KxizHVZ4xY+h4FhHTfawE32" \
    "mIgv9UpIBxJB4uX5Un0ywGHQxBp8Vx41XdSS9QXiqNJuan9SNM6LpzKVEXSsXTxX" \
    "cUTMvNKrNzGJkzPwhE7M1X0EMSZkM2qK0IvrwVHTe3Tb0Tvjd6PO5clRVz3HX96f" \
    "UtZtojQPkHUJQcb3KUl3WwQAXTWoycIhlQVXwq9zyxqdTxOFzCzSyLZLDWgSUYQ0" \
    "jBkViM0GUhUH/++2kXZtHrwcfSuo3QjktldvElZcf6jMEYrtVhuQpYQX24k3ZCYC" \
    "auJW4/F6KHflNO2XJ5OzV2ICkzpClLon8WmA4mUnw0GBY5SGOWk/gOLHGtAjvKUe" \
    "0WmRQ2E8aIYZEPruWzvKQbwc41rTyiTISG6ncONsGVTh2FG2BOHDJ8hks8FTAO18" \
    "fbDUyUvCnaVKicJDqFSK38rvg1C2rV5iUKJV0qXaaz9AWuzbFKPwutufBmsGunZX" \
    "N0zwxUSCmu1DDZkt13dg3buOOp74LMD9vUxFay0WGdUXF65DTsrFi/tPBDyxgh9L" \
    "8z6kACuVKPI2LP4jeImqk8dky0l69EY7bgUMf9Aga6f8uBV1+Uqmm30d7/gtdmm9" \
    "e5jrjY4XJj6396zLDVuKA6qGr0hF2MVHc2O+rKKNqh7Rts1guCUK/r4mXBQOyho/" \
    "xwVvhkDM0XdTD6cMQpKp965gBq3yN/vQH5xtw0RCfWig/R9Zat3t8yp13J4+Of9A" \
    "RDem9G5msyyZhySSrEpMpM1Vyg+PUAb1oO0Qn0GO02mtsFcNAGtq2FmWLqTBGl9E" \
    "QthddKgfGjPgnQBxVDWuuNDz9FINsDRxvntk3FlkwAfDu4YaIg9mTN5zAvKx7r8V" \
    "VD0tbxkws3H7SMItqNYgswBDCfa3PkbPnDuYc0/xSX3qjsYce45v2KvW6SX/l5rE" \
    "sRJacgXx84aQtWbnfCW7fA=="                                         \
    "-----END ENCRYPTED PRIVATE KEY-----"

#define CA_CERT_BUF_SIZE (sizeof(CA_CERT_BUF) - 1)
#define SVR_CERT_BUF_SIZE (sizeof(SVR_CERT_BUF) - 1)
#define SVR_KEY_BUF_SIZE (sizeof(SVR_KEY_BUF) - 1)

#endif
